
# Run the code chunk (from here until the  } # - - - - - ) 
# Nothing will happen, as it simply load the command into your environment
# you run the jenks_zero_map command afterwards to make the maps

jenks_zero_map <- function(data, variable, n_classes=6, palette= "brewer.pu_rd",
                           zero_colour="blue4",title=NULL,basemap=TRUE) {
  
  #- Keep your main table clean, make a copy called tmp
  tmp <- dplyr::select(data, variable = dplyr::all_of(variable))
  
  
  #-This calculates the Jenks breaks for your variable & rounds to 1 decimal place
  breaks  <- suppressWarnings(classInt::classIntervals(tmp$variable, n = n_classes, style = "jenks")$brks)
  rounded <- round(breaks, 1)
  
  
  #- Jenks sometimes makes zero a class, then two breaks are both 0 and it gives an error
  #-  This explains the error
  test <- any(duplicated(c(0, breaks[-1])))
  if(test == TRUE) {
    errormessage <- paste("With ", n_classes,
                          " classes, two breaks are the same. Try a smaller n_classes")
    stop(errormessage,call. = FALSE)
  }
  
  
  #-Find the upper and lower limits. 
  upper <- rounded[2:(n_classes + 1)]      # every break except the first
  lower <- rounded[1:n_classes] + 0.1      # every break except the last
  
  
  #- Join them into labels and put "0" at the front
  old_labels <- c("0", sprintf("%.1f - %.1f", lower, upper))
  
  
  #- Find the class of every polygon.
  #  (Putting -Inf and 0 at the start makes the separate zero class)
  tmp$classes <- cut(tmp$variable, breaks = c(-Inf, 0, breaks[-1]), labels = old_labels)
  

  
  #- Count the polygons in each class. Add the counts to the labels between ( )
  class_counts <- as.vector(table(tmp$classes))
  levels(tmp$classes) <- paste0(old_labels, " (", class_counts, ")")
  
  
  #- The colours: the zero colour, then one colour per class
  my_colours <- c(zero_colour, cols4all::c4a(palette, n_classes))
  
  
  #- Make the map
  finalmap <- tmap::tm_shape(tmp) +
    tmap::tm_polygons(fill        = "classes",
                      col         = "white",
                      fill.scale  = tmap::tm_scale_categorical(values = my_colours),
                      fill.legend = tmap::tm_legend(title = title))
  
  if(basemap == TRUE){finalmap <- finalmap+tm_basemap()}
  #- and send it back to you!
  return(finalmap)
}

# End of command
# - - - - - - - - 