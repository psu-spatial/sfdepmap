#============================================================================
# MAKE EXTRA MAP LAYERS FOR DC
#
# Makes three layers, all in EPSG:26985 (NAD83 / Maryland, metres), and saves
# them in one file, DC_extra_layers.gpkg:
#
#     extra_wards   the 8 wards (for politics / orientation)
#     extra_water   the larger rivers and lakes, as one shape
#     extra_FHA     1937 FHA grades in three broad classes (A-B, C-E, F-H)
#
# Needs the internet (tigris downloads and the FHA map server).
#============================================================================
 library(sf)
 library(tmap)
 library(tigris)
 library(dplyr)



#============================================================================
# 1. CITY BORDER
# DC is a single congressional district, so that layer gives the outline.
# Only used to crop the other layers.
#============================================================================
 city_border <- congressional_districts(state = "DC") %>%
                   st_transform(crs = 26985) %>%
                   st_make_valid() %>%
                   st_union()



#============================================================================
# 2. WARDS
# The Census Bureau files DC's 8 wards as "upper chamber" legislative districts
#============================================================================
 extra_wards <- state_legislative_districts("DC", house = "upper") %>%
                   st_transform(crs = 26985)

 qtm(extra_wards)



#============================================================================
# 3. RIVERS AND LAKES (Potomac, Anacostia, Tidal Basin...)
#============================================================================
 DC_water_sf <- area_water(state = "DC", county = "District of Columbia") %>%
                   st_transform(crs = 26985) %>%
                   st_make_valid()

    #---- Keep the larger water bodies (over 50,000 square metres), merged into one shape
     DC_water_sf <- filter(DC_water_sf, as.numeric(st_area(DC_water_sf)) > 50000)

     extra_water <- st_sf(water     = "Rivers and lakes",
                          geometry = st_make_valid(st_union(DC_water_sf)))

 qtm(extra_water)



#============================================================================
# 4. 1937 FHA RESIDENTIAL SUB-AREA GRADES
#
# Source: Mapping Segregation in Washington DC (Prologue DC), digitised from
#         the FHA Housing Market Analysis, 1937 (National Archives).
#         Created by Sarah Shoenfeld.
#
# Layer:  https://services.arcgis.com/8df8p0NlLFEShl0r/arcgis/rest/services/FHA_Grades/FeatureServer/0
# Item:   https://www.arcgis.com/home/item.html?id=40eb06c548f9400b8413798feb4dc22e#overview
#============================================================================

  #----------------------------------------------------------------------
  # 4a. Read the layer, and clip it to the city (it includes the suburbs)
  #----------------------------------------------------------------------
   fha_url <- paste0("https://services.arcgis.com/8df8p0NlLFEShl0r/arcgis/rest/services/",
                     "FHA_Grades/FeatureServer/0/query?where=1%3D1&outFields=*&f=geojson")

   Borders <- st_read(fha_url, quiet = TRUE) %>%
                 st_transform(crs = 26985) %>%
                 st_make_valid() %>%
                 st_intersection(city_border)


  #----------------------------------------------------------------------
  # 4b. Grade columns
  #     Subgrade keeps the full code (e.g. "C4"). Grade is the letter, A to H.
  #     Grade_class groups the eight grades into three broad classes.
  #----------------------------------------------------------------------
   Borders <- Borders %>%
                 mutate(Subgrade    = Grade,
                        Grade       = factor(substr(Subgrade, 1, 1),
                                             levels = LETTERS[1:8], ordered = TRUE),
                        Grade_class = case_when(
                                         Grade %in% c("A","B")     ~ "Rated A-B",
                                         Grade %in% c("C","D","E") ~ "Rated C-E",
                                         Grade %in% c("F","G","H") ~ "Rated F-H"),
                        Grade_class = factor(Grade_class,
                                             levels  = c("Rated A-B","Rated C-E","Rated F-H"),
                                             ordered = TRUE))

    #---- Check: number of sub-areas in each class
     table(Borders$Grade_class, useNA = "ifany")

  #----------------------------------------------------------------------
  # 4c. Merge each class into one shape, and close the hairline gaps
  #
  # The digitised sub-areas do not quite meet, which leaves thin slivers
  # inside each class. Growing each class by 40 m and shrinking it back by
  # 40 m fills any gap narrower than 80 m. Wider gaps (parks, rivers) stay.
  #----------------------------------------------------------------------
   extra_FHA <- Borders %>%
                   group_by(Grade_class) %>%
                   summarise() %>%
                   st_make_valid() %>%
                   st_buffer(dist =  40, joinStyle = "MITRE") %>%
                   st_buffer(dist = -40, joinStyle = "MITRE") %>%
                   st_make_valid()
     
     #---- Keep only the highest and lowest classes for the borders
     FHA_ends <- filter(extra_FHA, Grade_class != "Rated C-E")
     FHA_ends$Grade_class <- droplevels(FHA_ends$Grade_class)
     

   qtm(FHA_ends, "Grade_class")



#============================================================================
# 5. SAVE
# One GeoPackage file with three layers. delete_layer = TRUE replaces a layer
# if it is already in the file, so the script can be re-run.
#============================================================================
 output_file <- "./Data/DC_extra_layers.gpkg"
 if(exists(output_file)){rm(output_file)}
 
 st_write(extra_wards, output_file, layer = "extra_wards", delete_layer = TRUE)
 st_write(extra_water, output_file, layer = "extra_water", delete_layer = TRUE)
 st_write(FHA_ends,   output_file, layer = "extra_FHA",   delete_layer = TRUE)

#---- Check: list the layers in the file
 st_layers(output_file)

 