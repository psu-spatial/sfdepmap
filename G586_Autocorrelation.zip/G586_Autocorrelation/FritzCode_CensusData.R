#============================================================================
# Load/Map census data for Washington DC from the 2024 American Community Survey
# HLG Fall 2026
#
# 1. SET-UP
#============================================================================

  #----------------------------------------------------------------------
  # 1a) Clear the workspace and load the libraries
  #     If you get an error, install the library using the Packages/Install button
  #----------------------------------------------------------------------
   rm(list = ls())

   library(tidyverse)   # data wrangling
   library(tidycensus)  # download census data (needs a census API key)
   library(tigris)      # download census boundaries
   library(sf)          # spatial data
   library(sfdep)       # neighbours, LISA and Getis-Ord
   library(tmap)        # maps
   library(dplyr)       # put dplyr last so that select/filter come from here

   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   # NOTES
   #   You also need a census API key! See step 2A in
   #   https://psu-spatial.github.io/Geog364-2026/lab-6---regression-and-spatial-residuals.html
   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



  #----------------------------------------------------------------------
  # 1b) Choose your state and map projection
  #
  #     Putting the options here means you only change them in one place.
  #     The rest of the script updates itself.
  #
  #     26985 is NAD83 / Maryland (in metres), which matches Washington DC.
  #----------------------------------------------------------------------
   MyState      <- "DC"
   MyProjection <- 26985






#============================================================================
# 2. DOWNLOAD DATA
#
# Get American Community Survey data for every census tract in Washington DC.
# This will only work if you have signed up for an API key! See above
#
# Washington DC is a city and a "state" at the same time, so downloading every
# tract in DC gives you the whole city. There is no need to crop to a city border.
#============================================================================
 Data_ACS_DC <- get_acs( survey = "acs5", year = 2024,
                         geography = "tract",
                         state     = MyState,
                         variables = c(
                            total_pop          = "B01003_001", # total population
                            total_house        = "B25001_001", # total housing units
                            race.total         = "B03002_001", # everyone (the total for the race/ethnicity table)
                            race.white         = "B03002_003", # ...White, not Hispanic or Latino
                            race.black         = "B03002_004", # ...Black or African American, not Hispanic or Latino
                            race.native        = "B03002_005", # ...American Indian & Alaska Native, not Hispanic or Latino
                            race.asian         = "B03002_006", # ...Asian, not Hispanic or Latino
                            race.pacific       = "B03002_007", # ...Native Hawaiian & Pacific Islander, not Hispanic or Latino
                            race.other         = "B03002_008", # ...some other race, not Hispanic or Latino
                            race.multi         = "B03002_009", # ...two or more races, not Hispanic or Latino
                            race.hispanic      = "B03002_012", # ...Hispanic or Latino (of any race)
                            income.total       = "B06010_001", # people aged 15+
                            income.gt75        = "B06010_011", # ...who have an income of $75,000 or more
                            edu.total          = "B06009_001", # people aged 25+
                            edu.bachelors      = "B06009_005", # ...whose highest degree is a bachelor's
                            edu.graduate       = "B06009_006", # ...whose highest degree is above a bachelor's
                            work.total         = "B08101_001", # workers aged 16+
                            work.home          = "B08101_049", # ...who work from home
                            internet.total     = "B28002_001", # households
                            internet.broadband = "B28002_004"),# ...that have broadband
                          geometry = TRUE,
                          output   = "wide")

  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  # CODE EXPLANATION
  #   The command is get_acs from the tidycensus package.
  #   Results are saved to a variable called Data_ACS_DC
  #
  #   Common options here, or see ?get_acs
  #
  #       survey     - One ("acs1"), three ("acs3") or five-year ("acs5") survey
  #       year       - What survey year do you want to download
  #       geography  - "tract" for census tract level data, "county" for county level data
  #
  #       state      - The 2 letter state abbreviation in quotes e.g. "DC"
  #       county     - The county name you want in "quotes" e.g. "Centre".
  #                    If it's missing it will download the entire state
  #
  #       geometry   - Set to TRUE to get spatial data
  #       output     - Do you want everything as one column ("tidy"),
  #                    or one column for each variable ("wide")
  #
  #       variables  - There are hundreds of variables you can download,
  #                    but you need the census code for each one.
  #                    I normally get these from google, but you can see them
  #                    all by running load_variables()
  #
  #   If something breaks, there's a tutorial here:
  #   https://walker-data.com/tidycensus/articles/basic-usage.html
  #
  #
  # ABOUT THE RACE AND ETHNICITY COLUMNS
  #   The US census asks two separate questions: your race, and whether you
  #   are Hispanic or Latino. Table B03002 combines them so that every person
  #   is counted in exactly ONE group:
  #       - Hispanic or Latino (of any race), or
  #       - one of the race groups, for people who are not Hispanic or Latino.
  #   This means the groups add up to the total, so the percentages add up to 100.
  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -






#============================================================================
# 3. TIDY/CHECK THE DATA
#============================================================================

  #----------------------------------------------------------------------
  # 3a) Fix the columns
  #
  #     The get_acs() command downloads TWO columns for each variable.
  #     To record this, tidycensus adds a letter to the end of every column name:
  #        E = The best guess of the variable in that tract (Estimate)
  #        M = How certain the census bureau are about that guess (Margin of error)
  #----------------------------------------------------------------------

    #---- QUICK CHECK: See the column names
     glimpse(Data_ACS_DC)


    #---- Select the estimate columns only, and remove the E from their names
     Data_ACS_DC <- dplyr::select(Data_ACS_DC,
                                  GEOID,
                                  NAME,
                                  total_pop          = total_popE,
                                  total_house        = total_houseE,
                                  race_total         = race.totalE,
                                  race_white         = race.whiteE,
                                  race_black         = race.blackE,
                                  race_native        = race.nativeE,
                                  race_asian         = race.asianE,
                                  race_pacific       = race.pacificE,
                                  race_other         = race.otherE,
                                  race_multi         = race.multiE,
                                  race_hispanic      = race.hispanicE,
                                  income_total       = income.totalE,
                                  income_gt75        = income.gt75E,
                                  edu_total          = edu.totalE,
                                  edu_bachelors      = edu.bachelorsE,
                                  edu_graduate       = edu.graduateE,
                                  work_total         = work.totalE,
                                  work_home          = work.homeE,
                                  internet_total     = internet.totalE,
                                  internet_broadband = internet.broadbandE)


    #---- QUICK CHECK: Make sure it worked
     glimpse(Data_ACS_DC)



  #----------------------------------------------------------------------
  # 3b) Set the map projection and fix any broken shapes
  #     You set MyProjection at the top of the script
  #----------------------------------------------------------------------
   Data_ACS_DC <- st_transform(Data_ACS_DC, MyProjection)
   Data_ACS_DC <- st_make_valid(Data_ACS_DC)



  #----------------------------------------------------------------------
  # 3c) Find the area of each tract
  #     st_area gives square metres, so divide by 1,000,000 to get square km
  #----------------------------------------------------------------------
   Data_ACS_DC$AREA_km2 <- as.numeric(st_area(Data_ACS_DC)) / 1000000



  #----------------------------------------------------------------------
  # 3d) Work out densities and percentages
  #     The answer is saved as a new table called DC_sf
  #----------------------------------------------------------------------
   DC_sf <- transmute(Data_ACS_DC,
                      GEOID, NAME, AREA_km2,
                      total_pop,
                      total_house,
                      pop_density_km2        = total_pop   / AREA_km2,
                      house_density_km2      = total_house / AREA_km2,
                      percent_white          = 100 * race_white    / race_total,
                      percent_black          = 100 * race_black    / race_total,
                      percent_asian          = 100 * race_asian    / race_total,
                      percent_hispanic       = 100 * race_hispanic / race_total,
                      percent_other          = 100 * (race_native + race_pacific +
                                                      race_other  + race_multi) / race_total,
                      percent_income_gt75    = 100 * income_gt75 / income_total,
                      percent_BAdegree       = 100 * (edu_bachelors + edu_graduate) / edu_total,
                      percent_workhome       = 100 * work_home / work_total,
                      percent_housebroadband = 100 * internet_broadband / internet_total)

    #---- QUICK CHECK: Make sure it worked
     glimpse(DC_sf)

   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   # CODE EXPLANATION
   #   transmute makes new columns and ONLY keeps the columns you list.
   #
   #   The five race/ethnicity percentages add up to 100 in every tract:
   #       percent_white, percent_black, percent_asian   (not Hispanic or Latino)
   #       percent_hispanic                              (Hispanic or Latino, any race)
   #       percent_other     (American Indian & Alaska Native, Native Hawaiian &
   #                          Pacific Islander, some other race, two or more races)
   #   The four small groups are joined into "other" because each one is a
   #   very small share of most DC tracts.
   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



  #----------------------------------------------------------------------
  # 3e) Remove missing data
  #
  #     Moran's I and LISA stop with an error if even one tract has a missing value.
  #
  #     Missing values happen when:
  #        - a tract has no people (parks, the river), because 0 / 0 has no answer
  #        - the census did not publish a number for that tract
  #----------------------------------------------------------------------

    #---- Remove any tract with an empty shape
     DC_sf <- dplyr::filter(DC_sf, !st_is_empty(geometry))

    #---- Remove tracts with fewer than 30 people (small totals mess up percentages)
     DC_sf <- dplyr::filter(DC_sf, total_pop >= 30)

    #---- Remove any tract containing ANY missing value
     DC_sf <- drop_na(DC_sf)

    #---- QUICK CHECK: How many tracts are left?
     nrow(DC_sf)

   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   # CODE EXPLANATION
   #   The dplyr:: means use the dplyr package for this command, as other
   #   packages also have commands called filter
   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



  #----------------------------------------------------------------------
  # 3f) Remove "islands"
  #     Because we are going to use contiguity (touching) neighbours,
  #     remove tracts that do not touch any other tract
  #----------------------------------------------------------------------

    #---- Count how many other tracts each tract touches
     DC_sf$n_touching <- lengths(st_touches(DC_sf))
     table(DC_sf$n_touching)

    #---- Keep the tracts that touch at least one other tract
     DC_sf <- dplyr::filter(DC_sf, n_touching > 0)



  #----------------------------------------------------------------------
  # 3g) Make the city border
  #     Merge the tracts that are left into one outline
  #----------------------------------------------------------------------
   CityBorder.sf <- st_union(DC_sf)

    #---- QUICK CHECK: Map it to see it's what you expect
     tmap_mode("view")
     qtm(CityBorder.sf, fill = "white", fill_alpha = 0.3, col = "blue", lwd = 2,
         basemaps = "OpenStreetMap")






#============================================================================
# 4. MAKE A QUICK MAP
#    Use tmap version 4 to map the percent_black column in the data
#============================================================================
 tmap_mode("view")

 tm_basemap("OpenStreetMap") +
 tm_shape(DC_sf) +
     tm_polygons(fill        = "percent_black",
                 fill.scale  = tm_scale_intervals(style = "jenks", n = 5, values = "brewer.yl_gn_bu"),
                 col         = NA,
                 fill.legend = tm_legend(title = "Percent Black (not Hispanic or Latino)"),
                 fill_alpha  = 0.7)


  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  # CODE EXPLANATION (there are many tmap tutorials online)
  #
  #   tmap_mode("view") makes the map interactive. tmap_mode("plot") makes a static map
  #
  #   Everything connected by a + or a , is one single command. So I
  #
  #     Load a basemap from Open Street Map (tm_basemap)
  #
  #     Then: Select the DC_sf dataset (tm_shape)
  #      And map it as polygons (tm_polygons) that are
  #          - Filled with colours taken from the percent_black column
  #          - Have no outlines (col = NA)
  #          - Are slightly transparent (fill_alpha = 0.7, out of 0-1)
  #          - Use the brewer yellow-green-blue colour scale, split into 5 groups using jenks
  #          - Have a legend explaining the topic
  #
  #   To map a different column, change "percent_black" and the legend title.
  #   names(DC_sf) lists the columns you can choose from.
  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 
 
 
 
