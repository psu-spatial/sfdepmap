#-----------------------------------------------------------------
# Spatial Autocorrelation New
# Helen Greatrex Fall 2026
#-----------------------------------------------------------------

###########################################################################
# R Homework Week 6
#
# In this week's project, you will use R to carry out a spatial autocorrelation
# of census tract level data from DC. The spatial autocorrelation analysis will 
# involve computing Moran's I, a Moran's I scatterplot and Geary's C.
# A significance test will also be conducted on the results of the Moran's I test
#
# Please submit a completed R script to Canvas
#
# INSTRUCTIONS ARE BELOW
#
# Consider using the vast R resources that are available on the Web to help your coding!!  
# You would be surprised how helpful performing a Web search for R questions can be
# For example, you could search on "how do I create a scatterplot in R"
#
# Please, please: DO NOT submit a Word Doc of this R code
# To receive full credit you must submit THIS completed script to Canvas
#
# Enter your solutions where you see #####ENTER CODE HERE#####
#
###########################################################################






###########################################################################
# 1. SET UP
###########################################################################

#============================================================================
# You should be running your Lab 6 project! 
# 
# Here we install and load the necessary packages, load the data, 
# set its map projection and set up some general plotting options
#============================================================================


  #----------------------------------------------------------------------
  # 1a) Install the special sfdepmap package
  #
  # One of your instructors, Dr Greatrex, made the sfdep package to make 
  # better LISA and Getis-Ord maps.
  # https://psu-spatial.r-universe.dev/sfdepmap
  #
  # You install it in a different way to other packages: 
  #    - Remove the # from the line below, 
  #    - Run the line ONCE (just like you only go to the app store once)
  #    - Then put the # back.
  #
  # (Install any other packages normally, using the Install button. See Lab 1)
  #----------------------------------------------------------------------
   #install.packages("sfdepmap", repos = c("https://psu-spatial.r-universe.dev","https://cloud.r-project.org"))



  #----------------------------------------------------------------------
  # 1b) Clear workspace and load the libraries
  #     If you get an error, install the library using the Packages/Install button
  #----------------------------------------------------------------------
   rm(list = ls())
   library(tidyverse)   # data wrangling
   library(spdep)       # old spatial package, good backup
   library(sf)          # spatial data
   library(sfdep)       # neighbours, LISA and Getis-Ord
   library(sfdepmap)    # Dr Greatrex's package to make LISA maps (needs install above)
   library(tmap)        # maps
   library(ggstatsplot) # nice stats diagrams
   library(olsrr)       # regression & general statistics
   library(classInt)    # choose class intervals
   library(moments)     # skewness test
   library(dplyr)       # put dplyr last so that select/filter come from here



  #----------------------------------------------------------------------
  # 1c) Set up a shared layout for maps 
  #
  # Adding these to several maps makes them the same size, with legends that line up.
  #
  #     SameLayout: Reserves 35% of the width, on the right of each map, for its legend.
  #                The four numbers are: bottom, left, top, right.
  #
  #     SameLegend: Puts the legend in that space, with fixed font sizes. 
  #
  #     oldpar saves the standard R plotting settings  
  #----------------------------------------------------------------------
   SameLayout <- tm_layout(meta.margins = c(0, 0, 0, 0.35), frame = FALSE) +
                 tm_options(component.autoscale = FALSE)
   

   SameLegend <- function(title) {
     tm_legend(title      = title,
               position   = tm_pos_out("right", "center"),
               frame      = FALSE,
               title.size = 0.9,
               text.size  = 0.7) }

   

   
   
   
   
###########################################################################
# 2 LOAD THE DATA
###########################################################################
   
   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
   # NOTES
   # You need to be running your project for this to work! (see Lab 1)
   # 
   #  - The "./" part of the address means that R is looking for your shapefile 
   #    in the project folders
   #
   #  - So the census files are in 
   #    your project folder / Data  / DC_Census_Tracts_Std_Prj 
   #
   #  - The advantage of this is that it works on both windows and Mac, and
   #    if you share this folder with someone else (or upload it to posit-cloud online),
   #    it will continue to work without modifications
   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    
   #----------------------------------------------------------------------
   # 2a) Load the census tract data
   #     You don't need to tell R about the other shapefile subfiles 
   #     as long as they're in the same folder
   #----------------------------------------------------------------------
   DC_sf <- st_read("./Data/DC_Census_Tracts_Std_Prj/DC_Census_Tracts_Std_Prj.shp")
   


   #----------------------------------------------------------------------
   # 2b) Load some border data
   #     I bundled together some additional datasets to compare your results against
   #     a gpkg file is the "new" shapefile. 
   #     You only need one file and you can even save several layers together
   #----------------------------------------------------------------------
   
   # these are OPTIONAL and just to help put your results in context
   
   #---- See what layers are there
   st_layers("./Data/DC_extra_layers.gpkg")
   
   
   #---- Use this to open the different layers. 
   extra_wards    <- st_read("./Data/DC_extra_layers.gpkg", layer = "extra_wards")
   extra_water    <- st_read("./Data/DC_extra_layers.gpkg", layer = "extra_water")
   extra_FHA      <- st_read("./Data/DC_extra_layers.gpkg", layer = "extra_FHA")
   
   
   
   
  #----------------------------------------------------------------------
  # 2c) Set the map projection for ALL DATA
  # In this case we are using EPSG:26985 (NAD83 / Maryland)
  #----------------------------------------------------------------------
   DC_sf          <-  st_transform(DC_sf,         crs=26985)
   extra_wards    <-  st_transform(extra_wards,   crs=26985)
   extra_water    <-  st_transform(extra_water,   crs=26985)
   extra_FHA      <-  st_transform(extra_FHA,     crs=26985)


   
   
   
   
   
###########################################################################
## 3. EXPLORATORY DATA ANALYSIS 
###########################################################################
#============================================================================
# Your job is to now understand your dataset.
#   
# I chose random columns as my goal was just to show you the important commands 
# If it doesn't include the statistics you need, ask google!
#
# More options here: https://psu-spatial.github.io/Geog364-2026/T5_Summarising.html
#============================================================================

  #----------------------------------------------------------------------
  # 3a) Explore the table
  #----------------------------------------------------------------------
   
    #---- Type its name to see its spatial properties and the first few rows of data
    DC_sf 
   
   
    #---- Open the spreadsheet in a new tab (remove the # to run it)
    #View(DC_sf)
   
   
   
    #---- Show which columns you have (and at the top, the number of rows/columns)
    glimpse(DC_sf)
    
    
    
    #---- Just the number of rows and columns
    dim(DC_sf)
    
    
    #---- List the column names
    names(DC_sf)
    
   

    
  #----------------------------------------------------------------------
  # 3b) Summary statistics
  #----------------------------------------------------------------------
    
    #---- General summary statistics
    summary(DC_sf)
    
    
    #---- Show summary statistics for selected columns
    summary(DC_sf[, c("AREASQMI", "SINGLEPERS", "BLACK", "WHITE")])
    
     
    #---- Or calculate individual metrics for an individual column
    #     na.rm=TRUE means ignore missing data& $ means "select this column"
    
        mean(DC_sf$POPDENSITY, na.rm=TRUE)
      median(DC_sf$AREASQMI,   na.rm=TRUE)
          sd(DC_sf$MARRIED,    na.rm=TRUE)
         var(DC_sf$MARRIED,    na.rm=TRUE)
       range(DC_sf$SINGLEPERS, na.rm=TRUE)
         IQR(DC_sf$SINGLEPERS, na.rm=TRUE)
    quantile(DC_sf$SINGLEPERS, na.rm=TRUE, c(0,0.1,0.25,0.5,0.75,0.9,1))
        
    
    
    
    
    
  #----------------------------------------------------------------------
  # 3c) Data wrangling:  Add new columns 
  #
  # Mutate allows you to do any maths on a column and save as a new column
  # (BLACK, WHITE and TOTAL00 are existing column names in DC_sf) 
  #
  # More options here: 
  #    - data wrangling https://psu-spatial.github.io/Geog364-2026/T8_Wrangle.html
  #    - missing data.  https://psu-spatial.github.io/Geog364-2026/T6B_MissingData.html  
  #----------------------------------------------------------------------
    
    #---- Calculate the percentage of people who identify as black or white per tract
    DC_sf <- mutate(DC_sf, pct_black = 100*BLACK/TOTAL00,
                           pct_white = 100*WHITE/TOTAL00 )
    
    
    #---- Set any tracts as missing/empty that only have one or two people in them
    DC_sf <- mutate(DC_sf, 
                    pct_black = ifelse(TOTAL00 <= 2, NA, pct_black),
                    pct_white = ifelse(TOTAL00 <= 2, NA, pct_white) )
     
    
    #---- Notice that new columns have been created
    names(DC_sf)
    

    #---- Show summary statistics for your updated columns
    summary(DC_sf[, c("BLACK","pct_black", "TOTAL00","POPDENSITY")])

   


      
      
  #----------------------------------------------------------------------
  # 3d) Explore the distribution with some plots
  #
  # More available here: 
  # https://psu-spatial.github.io/Geog364-2026/T6_plots.html#T6_boxplots
  #----------------------------------------------------------------------
     
     #---- Make a histogram
     gghistostats(
       data       = DC_sf,      # table name
       x          = pct_black,  # column name
       results.subtitle = FALSE,
       title      = "Percentage of adults per DC census tract identifying as Black",
       caption    = "Source: US Census [2000]",
       xlab = "Percentage")
     
     
     
     #---- Or a boxplot
     boxplot(DC_sf$pct_black,
             main = "Percentage of adults per DC census tract identifying as Black",
             xlab = "Percentage",
             ylab = "Frequency",
             col = "lightblue",
             border = "darkblue",
             horizontal = TRUE,
             notch = TRUE)
     
     
     #---- Check normality and skew (removing any missing values)
     ols_test_normality(na.omit(DC_sf$pct_black))
     agostino.test(na.omit(DC_sf$pct_black))
     
     
     
     
  #----------------------------------------------------------------------
  # 3e) Make a simple exploratory map
  #----------------------------------------------------------------------
   
   # also try tmap_mode("view")
   tmap_mode("plot") 
     
   tm_shape(DC_sf) +
       tm_polygons(
         fill        = "pct_black",
         col         = "white",
         fill.scale  = tm_scale_intervals(style = "jenks",n = 6,values = "brewer.pu_rd"),
         fill.legend = tm_legend(title = "Percent Black"))  
   
   
   
   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
   # Notes
   # tmap_mode("plot") means a static map, 
   # tmap_mode("view") means an interactive map (try it!)
   #
   # - tm_shape    = The data/spreadsheet you want to map
   # - fill        = The column name you want to map
   # - fill.scale  = Your color scale. In this case,use jenks breaks, with 6 classes
   #                    and brewer purple red color palette ()
   # - fill.legend & tm_title = The legend & title
   # - fill_alpha and col_alpha = transparency of the fill and borders respectively
   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    
   #----------------------------------------------------------------------
   # 3d) Make an exploratory map with more layers
   #     You can also add more layers using + and sf_shape()
   #
   #     So you can now see how your pattern compares with that additional data
   #----------------------------------------------------------------------
   
   #---- First, create a main map you like. 
   #     I change the transparency fill/col alpha depending if I'm using a basemap
   
   main_map <- tm_shape(DC_sf) +
     tm_polygons(
       fill        = "pct_black",
       col         = "pct_black",
       col.scale   = tm_scale_intervals(style = "jenks",n = 6,values = "viridis"),
       fill.scale  = tm_scale_intervals(style = "jenks",n = 6,values = "viridis"),
       fill_alpha  = .3, col_alpha = .3,
       fill.legend = tm_legend(title = "Percent Black"),
       col.legend = NULL)

   
   #---- And add layers! Example 1.
   #     To see how your pattern relates to how it applies to historic house zones,
   #     and local rivers:
   #       - Plot the main map you just saved
   #       - Then add the rivers/lakes   
   #       - Then add the borders of the historic FHA Districts

   tmap_mode("plot")
   
   main_map +
   tm_shape(extra_water) +
     tm_polygons(fill  = "water",
                 col   = "#BEE5EF",
                 fill.scale   = tm_scale_categorical(values = "#BEE5EF"),
                 fill.legend  = tm_legend(title = "Water"))   +
   tm_shape(extra_FHA) +
     tm_borders(col = "Grade_class",
                col.scale   = tm_scale_ordinal(values = c("darkgreen", "firebrick2")),
                lwd         = 2,
                col.legend  = tm_legend(title = "1937 FHA Zone"))
   
   
   #---- And add layers! Example 2
   #     To see how it applies to modern voting districts
   #       - Plot the main map you just saved
   #       - Then add the borders of the legislative zones
   
   tmap_mode("view") 
   
   main_map +
   tm_shape(extra_wards) +
     tm_borders( col = "black",
                 lwd = 1.5,
                 col.legend = tm_legend(title = "2020 State legislative districts"))  
   
   
   
   
 
  #----------------------------------------------------------------------
  # 3e) Map with full control of the colour classes & labelled counts
  #
  # To keep your lab easy to read, I put the code for this in a custom
  #    command (jenks_zero_map). 
  #
  # This command will work as long as you have the file "G586_Function_JenksZeroMap.R" 
  #    stored in your project folder.
  #
  # If you're interested in learning how I made this (not too hard!) 
  #    open the G586_Function_JenksZeroMap.R file & take a look
  #----------------------------------------------------------------------
  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  # Note for Fritz: 
  # If I have time, I'll try to set it up so it differentiates between missing and empty
  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   
    # Load the command. jenks_zero_map() will appear in your environment.
    # If you get an error, check this file is in your project folder
    # and that you're running your project
    #----
    source("G586_Function_JenksZeroMap.R")

    
    # Now use the command to make the map 
    #---- 
    tmap_mode("plot")
    jenks_zero_map(data        = DC_sf,
                   variable    = "pct_black",
                   n_classes   = 6,
                   palette     = "brewer.pu_rd",
                   zero_colour = "blue4",
                   basemap     = FALSE,
                   title       = "Percent of adults identifying as Black")

     

  

    
    

################################################################################
# 4. CALCULATING NEIGHBOURS & SPATIAL WEIGHTS
#
# Now we calculate what is meant by a "neighbour" of each polygon, 
# and store this in a spatial weights matrix (a look up table)
################################################################################
    
 #============================================================================
 # 4A. REMOVE MISSING DATA/POLYGONS
 #============================================================================
    #----------------------------------------------------------------------
    #   Moran's I and LISA can stop with an error if even one tract has a missing value.
    #
    #   Missing values happen when:
    #      - a tract has no people (parks, airports, the lake), because 0 / 0 has no answer
    #      - the census did not publish a number for that tract
    #
    #   This step comes AFTER the percentages are calculated, so that it
    #   also removes any tract where a percentage could not be worked out.
    #
    #   Look carefully at your results above and you will see that we have 
    #   empty tracts like this in our data.    
    #----------------------------------------------------------------------
    
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    # This code:
    #  Removes any "empty" tract
    #  Removes census tracts with less than 30 people (can't trust percentages!)
    #  (Re)-fixes any broken shapes
    #  Overwrites the DC_sf table
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    DC_sf <- DC_sf %>%
      dplyr::filter(!st_is_empty(geometry)) %>%
      dplyr::filter(POPDENSITY > 0) %>%
      dplyr::filter(TOTAL00 > 30) %>%
      st_make_valid()
    
    
    #---- Check to see it if worked
    summary(DC_sf[, c("BLACK","pct_black", "POPDENSITY","TOTAL00","TOTAL90")])
    
    
    
#============================================================================
# 5. WORK OUT WHO YOUR NEIGHBOURS ARE
#============================================================================
  #----------------------------------------------------------------------
  # 5a) Decide who is a neighbour of who
  # Create a neighbourhood matrix & check the output makes sense
  #----------------------------------------------------------------------
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    # Notes,
    # You don't need to use queens 1st order. Here are other options 
    # you can switch out for the NeighbourMatrix line above
    # Everything after this section works the same.
    #
    #  -- ROOK CONTIGUITY:
    #       NeighbourMatrix <- st_contiguity(DC_sf, queen = FALSE)
    #
    # 
    #  -- K-NEAREST NEIGHBOURS, based on polygon centres (set to 6 neighbours here)
    #       Tract_Centres   <- st_centroid(st_geometry(DC_sf))
    #       NeighbourMatrix <- st_knn(Tract_Centres, k = 6)
    #
    # 
    #  -- DISTANCE BANDS: set here to every tract whose centre is within 2 km (2000 m).
    #     Distance is in the units of your map projection:
    #       Tract_Centres   <- st_centroid(st_geometry(DC_sf))
    #       NeighbourMatrix <- st_dist_band(Tract_Centres, upper = 2000)
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    #---- 1st order Queens contiguity
    NeighbourMatrix <- st_contiguity(DC_sf, queen = TRUE)
    
    
    #---- Type its name to see a summary
    NeighbourMatrix
    
    
     

    
  #----------------------------------------------------------------------
  # 5b) Simple map of the neighbourhood links to check they make sense
  #     Here we use standard r plot rather than tmap
  #  
  #     Edit the plot command, then run all of this code together. 
  #     I explain the code options at the end of 3c  
  #----------------------------------------------------------------------
 
    # a. Get rid of the margins/whitespace
    # b. Map the borders
    # c. Add the links
    # d. Then.. go back to normal plot margins
    #----     
    
     par(oma=c(0,0,0,0),mar=c(0,0,0,0))
    
     plot(st_geometry(DC_sf), border = 'grey')
     plot(NeighbourMatrix, st_geometry(DC_sf), col = 'black', lwd = 1, cex = .2, add = TRUE)
     
     par(oma=c(0,0,0,0),mar=c(5.1, 4.1, 4.1, 2.1))
     
     

     
  #----------------------------------------------------------------------
  # 5c) Labelled map of the neighbourhood links to check they make sense
  #     Edit the plot command, then run all of this code together. 
  #----------------------------------------------------------------------
     
     # a. Get rid of the margins/whitespace
     # b. Map the borders
     # c. Add the links
     # d. Add white circles at the centre of each tract
     # e. Write the tract number in each circle
     # f. Then.. go back to normal plot margins
     #----   
     
     par(oma=c(0,0,0,0),mar=c(0,0,0,0))
     
     plot(st_geometry(DC_sf),col = "darkgrey", border = "deepskyblue3")
     plot(NeighbourMatrix, st_geometry(DC_sf),    
          col = "orange", pch = 19, cex = 0.3, lwd = 1.5, add = TRUE)
     plot(st_geometry(st_point_on_surface(DC_sf)),col = "white", pch = 20, cex= 2, add=TRUE)
     text(st_point_on_surface(DC_sf), labels = DC_sf$OBJECTID_1, cex = 0.4, font = 2)
     
     par(oma=c(0,0,0,0),mar=c(5.1, 4.1, 4.1, 2.1))
     
     
     
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    # CODE EXPLANATION
    #   lwd    = line width
    #   cex    = dot size, or font size
    #   pch    = symbol type
    #   add    = TRUE means put a second layer on top
    #   col    = line colour or fill colour
    #   border = polygon border colour
    #   st_geometry means only plot the borders, not the content
    #   st_point_on_surface means either the centroid, or some point within the borders
    #   mar and oma are the white space margins
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


     
     
     
     
#============================================================================
# 6. CALCULATE THE SPATIAL WEIGHTS MATRIX
# Here we're storing the neighbours of each polygon in a look-up table 
#============================================================================
     
  #----------------------------------------------------------------------
  # 6a) Binary weights (style = "B")
  #   
  # Every neighbour gets a weight of 1, so different rows add up to different numbers
  # allow_zero = TRUE stops errors if a tract has no neighbours    
  #----------------------------------------------------------------------
   WeightsMatrix_binary <- st_weights(NeighbourMatrix,  
                                      allow_zero = TRUE, 
                                      style = "B")

     
     
  #----------------------------------------------------------------------
  # 6b) Row standardised weights (style = "W")
  #   
  # Divide the B style by the number of neighbours, so each polygon's neighbours add up to 1
  # allow_zero = TRUE stops errors if a tract has no neighbours    
  #----------------------------------------------------------------------
   WeightsMatrix_standardised <- st_weights(NeighbourMatrix, 
                                            allow_zero = TRUE, 
                                            style = "W")

    
  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  # NOTES,
  #   
  #---- WHAT ABOUT OTHER FORMS OF NEIGHBOUR? (E.g. knn, distance bands)
  #       We're using st_weights() given that our neighbours are queens/rooks contiguity, but
  #       there are also other spatial weights commands such as st_inverse_distance(), 
  #       st_kernel_weights(), st_nb_dists()
  #
  #
  #---- IN STEP 5, SHOULD YOU USE WEIGHTS=W or WEIGHTS=B?
  #
  #   W: Each tract's spatial lag is the average of its neighbours.
  #      The slope of the Moran scatterplot equals Moran's I,
  #      and "High-Low" on a LISA map reads naturally as "high value, low neighbour average".
  #
  #   B: The spatial lag is the sum of the neighbours, so tracts with more neighbours
  #      carry more weight in the statistic. The test is still valid. 
  #
  #    The two usually give similar but not identical values in autocorrelation metrics.  
  #    
  #     - Moran's I and LISA work with either. "W" is the usual choice, because the 
  #       spatial lag is then the average of the neighbours, making the plot easier to read.  
  #    
  #     - Binary weights are recommended for Getis-Ord. 
  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

     
     
     
     
     
     
     
################################################################################
# MEASURING AUTOCORRELATION
#
# We now have our data, and we know the neighbours of each census tract, so we can
# now calculate autocorrelation (whether the values at a census tract are similar to
# its neighbours or the region as a whole)
#
# There are many ways to do this, so this code showcases     
#   - Global Moran's I
#   - Local Moran's I (LISA/Cluster & Outlier analysis)
#   - Global Geareys C
#   - Local Geareys C    
#   - Local Getis Ord
#.  - Local Getis Ord*    
#
# Finally, we make a summary graphic showing all of these to compare/contrast
#    
################################################################################
    
#============================================================================
# 7.  GLOBAL MORAN'S I
#     
# Is there autocorrelation across the WHOLE study area?
#
# We first look to see how this appears on a moran's scatterplot (Morans I is the slope)     
# Then we calculate the global moran's I hypothesis test using a few different ways
# of calculating the expected Moran's I from random chance.
#
#============================================================================

  #----------------------------------------------------------------------
  # 7a)  MORAN'S SCATTERPLOT
  #----------------------------------------------------------------------
     
     moran_scatterplot(data    = DC_sf,
                       variable   = "pct_black",
                       label      = "GIS_ID",
                       neighbours = NeighbourMatrix,
                       weights    = WeightsMatrix_standardised,
                       standardise  = FALSE,
                       annotate     = FALSE, 
                       title        = "Percent Black per DC census tract")
     
     
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     # annotate = TRUE will allow you to see explanatory labels and colors. 
     #   
     # If annotate =TRUE,  you can also choose any of the  built in LISA palettes 
     #   so your scatterplots match your maps   
     #  
     #     'palette' can be a palette number (1 to 6), 
     #                      a palette name ("red_blue" , "pastel".   , "bright", 
     #                                     "black_gold", "green_blue", "brown_teal"), 
     #                        or 5 colours of your own in this order: 
     #                        High-High, High-Low, Low-High, Low-Low, Not significant.      
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     
      moran_scatterplot(data    = DC_sf,
                     variable   = "pct_black",
                     label      = "GIS_ID",
                     neighbours = NeighbourMatrix,
                     weights    = WeightsMatrix_standardised,
                   standardise  = FALSE,
                   annotate     = TRUE, 
                   palette      = 3,
                   title        = "Percent Black per DC census tract")
     
     
   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   # HOW TO READ THE MORAN SCATTERPLOT
   #   
   # Hint 1: make the plot screen large/full screen to see it properly
   #
   #   x axis: the value in each tract
   #   y axis: the average value in that tract's neighbours
   #   The most unusual tracts are labelled with their GIS_ID
   #   
   #   The dotted lines are 
   #        the overall mean of the value in each tract (mean(x)), and
   #        and overall mean of the the average value in that tract's neighbours (mean(y)) 
   #
   #   So that means 
   #      - Any point in the TOP-RIGHT quadrant is a HOT-CLUSTER
   #           A higher than average value compared to the whole study area
   #           And neighbours (on average) with higher than average values 
   #           (HIGH surrounded by HIGH) 
   #
   #      - Any point in the BOTTOM-LEFT quadrant is a COLD-CLUSTER with 
   #           A lower than average value compared to the whole study area
   #           And neighbours (on average) with lower than average values 
   #           (LOW surrounded by LOW) 
   #   
   #      - Any point in the BOTTOM-RIGHT quadrant is an OUTLIER with 
   #           A higher than average value 
   #           BUT! neighbours (on average) with lower than average values 
   #           (HIGH surrounded by LOW) 
   #
   #      - Any point in the TOP-LEFT quadrant is an OUTLIER with 
   #           A lower than average value 
   #           BUT! neighbours (on average) with higher than average values 
   #           (LOW surrounded by HIGH) 
   #   
   #   
   # MORAN'S I is the slope of the line on this plot, 
   #   as long as the weights are row-standardised (style = "W") 
   #   and every tract has at least one neighbour. 
   #  
   # MORAN'S I usually falls between -1 and 1.  
   #   Near  1 : similar values sit next to each other (clustered)
   #   Near  0 : no spatial pattern. The expected value is -1/(n-1)
   #   Near -1 : high values sit next to low values (checkerboard)
   # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     
   
   
   #----------------------------------------------------------------------
   # 7b) SCALED MORAN'S SCATTERPLOT (standardise = TRUE)
   # The moran's scatterplot can sometimes be easier to read if we scale the
   # x and y axes, because then mean-x and mean(lag-x) sit in the middle
   #
   # annotate =TRUE still turns on/off the coloring and explanatory labels   
   #----------------------------------------------------------------------
     moran_scatterplot(data         = DC_sf,
                       variable     = "pct_black",
                       label        = "GIS_ID",
                       neighbours   = NeighbourMatrix,
                       weights      = WeightsMatrix_standardised,
                       standardise  = TRUE,
                       annotate     = TRUE,
                       palette      = 1,
                       title        = "Percent Black per DC census tract")
     
      
   
     
  #----------------------------------------------------------------------
  # 7c)  CALCULATING MORAN'S I AND TESTING IF IT'S SIGNIFICANTLY DIFFERENT 
  #      TO A PATTERN CAUSED BY AN INDEPENDENT RANDOM PROCESS
  #    
  # There are three ways that we can calculate the expected Moran's I
  # if an independent random process (random chance) caused the pattern   
  #----------------------------------------------------------------------

     
     # Global_moran_test with randomization = FALSE:
     #    Assumes the data are normally distributed, and gets the p-value  
     #    from a normal curve for Moran's I.
     #----      
     global_moran_test(x  = DC_sf$pct_black,
                       nb = NeighbourMatrix,
                       wt = WeightsMatrix_standardised,
                       zero.policy = T,
                       randomization = FALSE)


     
     # Global_moran_test with randomization = TRUE:
     #       Assumes only that the observed values could have landed at any location.
     #       Calculates the exact mean and variance of Moran's I across all such shuffles
     #       using a formula, and gets the p-value from a normal curve with 
     #       that mean and variance.     
     #----      
     global_moran_test(x  = DC_sf$pct_black,
                       nb = NeighbourMatrix,
                       wt = WeightsMatrix_standardised,
                       zero.policy = T,
                       randomization = TRUE)
     
     
     
     
     # Monte Carlo Global Moran Permutation Test
     #       Moran's test, with the p-value from shuffling the data (Monte Carlo)
     #       Assumes only that the observed values could have landed at any location.
     #       It shuffles them nsim times, and gets the p-value by comparing the 
     #       observed Moran's I with the shuffled ones.  
     #
     #----      
     global_moran_perm(x  = DC_sf$pct_black,
                       nb = NeighbourMatrix,
                       wt = WeightsMatrix_standardised,
                       zero.policy = T,
                       nsim = 500)
     
      
      # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
      # CODE EXPLANATION
      #   nb = your chosen neighbourhood matrix
      #   wt = your chosen spatial weights matrix
      #   zero.policy = T, make it ignore missing/zero data
      #   nsim = number of random shuffles (the more the better)   
      # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
      
     
     
     
     # Visualise results 
     #     We can visualise the output of the Global Moran Permutation Test
     #     using a histogram & compare it to the actual moran's I of our dataset. 
     #
     #     To do this, lets run again, but this time, save the results as moran_mc
     #     Then 
     #     a) Plot the histogram of the simulated morans I values
     #     b) Add faint gridlines, and draw a box around the plot
     #     c) Add the observed Moran's I on top as a red line
     #     d) Add a note in the margin to say as much
     #----      

     moran_mc <- global_moran_perm(x  = DC_sf$pct_black,
                                   nb = NeighbourMatrix,
                                   wt = WeightsMatrix_standardised,
                                   zero.policy = T, nsim = 500)

     
     hist(moran_mc$res,   breaks = 30,
          main   = "Monte Carlo distribution of Moran's I",
          xlab   = "Moran's I under shuffling", ylab   = "Count",
          col    = "grey80",  border = "white", las = 1)
     
     grid(); box()
     
     abline(v = moran_mc$statistic, col = "red", lwd = 2)
     mtext("Red line = observed Moran's I", side = 3, line = 0.3, cex = 0.9)
     
     
     
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    # HOW TO READ THIS PLOT
    #   The point of this hypothesis test is to see the likelihood of observing your
    #   Moran's I in a world where random chance causes the pattern.
    #   The histogram shows many simulated Moran's I values from random patterns,
    #   and the red line shows the value we got for our data.
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

     
     

     
     
     


#============================================================================
# 8. MORAN'S I CORRELOGRAM
# How does Moran's I change as "neighbours" get further apart?
#      
# There are a few ways we can look at this.  
#============================================================================

  #----------------------------------------------------------------------
  # 8a) Using st_continuity lags
  # neighbours, then neighbours-of-neighbours, ... up to 6 steps away:
  #   x=1:Queens 1st order neighbours  
  #   x=2:Queens 2nd order neighbours  
  #   x=3:Queens 3rd order neighbours..  
  #   
  # This is built into R so it's very easy, but its hard to get a good plot
  #----------------------------------------------------------------------
   Correlogram <- sp.correlogram(NeighbourMatrix, DC_sf$pct_black,
                                 order = 6, method = "I",
                                 style = "W", zero.policy = TRUE)

       
   plot(Correlogram, 
        main=list("Lagged Moran's I of the percentage of people 
                   identifying as black in DC (Queens Continuity)",cex=1))
        
   


  #----------------------------------------------------------------------
  # 8b): distance bands
  # 
  # We repeat the Moran's test but this time go back and choose our neighbours
  # according to distance bands. 
  #  e.g.
  #   x: 0-1km : Neighbours are any polygon with a centroid closer than 1km  
  #   x: 1-2km : Neighbours are any polygon with a centroid 1-2km away... etc
  # 
  #   For each band, this calculates same three steps as before: 
  #     neighbours, weights, Monte Carlo test.
  #   Then it saves the Moran's I value and the p-value 
  #----------------------------------------------------------------------

   
    #---- First, choose your options 
       # What distance band spacing do you want? 
       # (in the units of your map projection (m for us, so 1000 = 1km))
       band_width <- 1000
   
   
       # What's your final plot title?      
       plot_title <- "Moran's I correlogram: percent Black per DC census tract"


   
    #---- Then plot
       # Scroll down and edit the command by "CHANGE THIS TO MATCH YOUR COLUMN OF INTEREST"
       #   e.g. change DC_sf$pct_black to match the dataset and column that YOU want to plot
       #
       # Then run the code between these dotted lines  
       
       
       # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
       
        #Find the tract centres and the starting distance of every band
        Tract_Centres <- st_centroid(st_geometry(DC_sf))
        max_dist   <- as.numeric(max(st_distance(Tract_Centres)))
        band_start <- seq(0, max_dist, by = band_width)
        

        #Create the output table. One row per band, with empty columns to fill in
        correlogram <- data.frame(lower = band_start,  
                                  upper = band_start + band_width,
                                  moran_i = NA,  p_value = NA)
        

        #Run Moran's I for each band using a for loop
        for (i in 1:nrow(correlogram)) {
          
           #Calculate neighbours for this distance band
           Band_Neighbours <- st_dist_band(Tract_Centres,
                                           lower = correlogram$lower[i],
                                           upper = correlogram$upper[i])

           #Skip the band if no tracts are this distance apart
           if (sum(card(Band_Neighbours)) == 0) next

           #Calculate weights
           Band_Weights <- st_weights(Band_Neighbours, allow_zero = TRUE,  style = "W")

           #CHANGE THIS TO MATCH YOUR COLUMN!
           #Calculate Moran's I and the p-value
           Band_Moran <- global_moran_perm(x    = DC_sf$pct_black,
                                           nb   = Band_Neighbours,
                                           wt   = Band_Weights,
                                           zero.policy = T,
                                           nsim = 500)

           #Save results
           correlogram$moran_i[i] <- Band_Moran$statistic
           correlogram$p_value[i] <- Band_Moran$p.value
        }
        
        
        #Find the midpoint in each band
        correlogram$midpoint_km <- (correlogram$lower + correlogram$upper) / 2 / 1000
        
        #Plot Moran's I against distance  
        ggplot(correlogram, aes(x = midpoint_km, y = moran_i)) +
          geom_hline(yintercept = 0, linetype = "dashed", colour = "grey50") +
          geom_line(colour = "grey40") +
          geom_point(aes(fill = p_value), shape = 21, size = 4, colour = "black") +
          scale_fill_viridis_c(option    = "viridis",
                               direction = 1,
                               limits    = c(0, 0.15),
                               oob       = scales::squish,
                               breaks    = c(0, 0.05, 0.1, 0.15),
                               labels    = c("0", "0.05", "0.10", "0.15 or more"),
                               name      = "p-value") +
          labs(x = "Distance between centroids (km)",
               y = "Moran's I",
               title = plot_title ) +
          theme_minimal()
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

     
        
        
        
        
        
        
        
        


#============================================================================
# 9. LISA (Local Moran's I / Cluster and Outlier analysis)
#
# Rather than taking the mean of the scatterplot, we can map each point  
# and color it based on which quadrant of the morans scatterplot it falls into
#        
# This means we can see WHERE the clusters and the outliers are, and how they relate 
# to the underlying geography? Each tract is coloured by the group it falls into:
#        
#     High-High = high value, surrounded by high values   (a cluster)
#     Low-Low   = low value,  surrounded by low values    (a cluster)
#     High-Low  = high value, surrounded by low values    (an outlier)
#     Low-High  = low value,  surrounded by high values   (an outlier)
#
#        
# Section 7a) shows how the LISA map is made  
# Section 7b) makes the finished map. This is what you normally do if it wasn't a class exercise
#        
#============================================================================

        
  #----------------------------------------------------------------------
  # 9a) UNDERSTANDING HOW LISA IS MADE 
  # With a LISA map, we are essentially taking each census tract, 
  # working out which quadrant it's in of the scatterplot, working out
  # if that result is unlikely to be caused by random chance, then mapping the colors      
  #----------------------------------------------------------------------
      

        #---- 1. Get the data
        LISA_pctblack_sf  <- lisa_map(data  = DC_sf,
                                    variable     = "pct_black",
                                    label        = "GIS_ID",
                                    neighbours   = NeighbourMatrix,
                                    weights      = WeightsMatrix_standardised,
                                    significance = 0.05,
                                    nsim         = 499,
                                    seed         = 501,
                                    return_data  = TRUE)
        
        # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        # CODE EXPLANATION
        #
        #   return_data = TRUE gives back an sf data object with 
        #      - The tract label, 
        #      - Your column of interest (pct_black here), 
        #      - the geometry 
        #      - and four new columns: 
        #         LocalMoran - the local moran statistic
        #         LocalMoran_pvalue - the localmoran_perm p-value
        #         LocalMoran_Quadrant - which quadrant that point falls into
        #         Quadrant_sig - adjusted to only keep points that are unlikely to be random chance
        #
        #  Note, the p-value is the likelihood of seeing this intensity of Local Moran's I if the
        #        pattern had been caused by an Independent Random Process (e.g. random chance)
        #           - Low values mean it is UNUSUAL to see this by chance
        #           - High values mean it is pretty common to see this by random chance
        #
        # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
       
        
        
        #---- 2. Map each of the new columns
        #        Nothing appears on your screen until the last command, tmap_arrange()  
        #
        # Note, The local_moran legend is set to be symmetrical 
        #        around zero. To do this, I find the largest absolute value of 
        #        Local Moran's I, then make a colour scale from -largest to +largest.
        
        largest  <- max(abs(LISA_pctblack_sf$LocalMoran))
        

         # Map the Local Moran's I values
         map_LocalMoran <- tm_shape(LISA_pctblack_sf) +
                                tm_polygons(fill = "LocalMoran",
                                     fill.scale  = tm_scale_intervals(
                                        values   = "brewer.br_bg",
                                        midpoint = 0,
                                        breaks   = seq(-largest,largest, length.out = 8)),
                                     fill.legend = SameLegend("Local Moran's I")) + SameLayout
        
       
         # Map the p-values
           map_pvalue <- tm_shape(LISA_pctblack_sf) +
                           tm_polygons(fill = "LocalMoran_pvalue",
                                 fill.scale = tm_scale_intervals(
                                     breaks = c(0, 0.01, 0.05, 0.1, 0.25, 1),
                                     values = c("#006d2c",
                                                "#238b45",
                                                "#99d8c9",
                                                "#ccece6",
                                                "white"),
                                     labels = c("p < 0.01", "0.01 - 0.05",
                                                "0.05 - 0.10", "0.10 - 0.25", "p > 0.25")),
                                  fill.legend = SameLegend("p-value")) + SameLayout
        
           
           # Map the raw quadrant each tract falls in
            map_LISA <- tm_shape(LISA_pctblack_sf) +
                          tm_polygons(fill = "LocalMoran_Quadrant",
                               fill.scale  = tm_scale_categorical(values = c("firebrick2",
                                                                             "lightpink", 
                                                                             "skyblue2",
                                                                             "royalblue3", 
                                                                             "white")),
                               fill.legend = SameLegend("Raw LISA Quadrants") ) + SameLayout
        
            

          # Map the quadrants, keeping only the tracts with p <= 0.05
           map_LISA_withP <- tm_shape(LISA_pctblack_sf) +
                               tm_polygons(fill = "Quadrant_sig",
                                    fill.scale  = tm_scale_categorical(values = c("firebrick2",
                                                                                  "lightpink", 
                                                                                  "skyblue2",
                                                                                  "royalblue3", 
                                                                                  "white")),
                               fill.legend = SameLegend("LISA quadrants") ) + SameLayout
        
           
         # And finally.. show the four maps together
          tmap_arrange(map_LocalMoran,map_pvalue,map_LISA,map_LISA_withP,nrow=2)
        

          
  #----------------------------------------------------------------------
  # 9b) STANDARD LISA MAPS
  # There's a built-in mapping command within sfdepmap that will allow
  # you to make static and interactive LISA maps with much less code.
  # It also writes summary statistics on the screen        
  #
  # New options below
  #  significance = the p-value cut-off. Tracts above it are shown as "not significant"
  #
  #   seed         = the p-values come from shuffling the data, so the map changes
  #                  slightly each time. Giving a seed makes it repeatable.
  #                  The seed that was used is written under the map.
  #        
  #   mode         = "view" makes the map interactive       
  #
  #   palette can be a number from 1-6 or 5 colors of your choice (see morans's scatterplot)    
  #----------------------------------------------------------------------

     #---- Final LISA map with caption
     lisa_map(data         = DC_sf,
              variable     = "pct_black",
              label        = "GIS_ID",
              neighbours   = NeighbourMatrix,
              weights      = WeightsMatrix_standardised,
              significance = 0.1,
              seed         = 364,
              palette      = 2,
              nsim         = 499,
              mode         = "plot",
              title        = "Percent Black per DC census tract",
              data_source  = "Data: US Census 2000.")
          
          
     #  p-value currently set to 0.1, change it to your threshold  
     #  Change the mode from "plot" to "view" to make it interactive!
     #     Remember you can change the basemap by clicking the layer button
     #     or click on a polygon to show details            

          
     #---- This corresponds to this moran scatterplot (with the points shaded to match)
     lisa_scatterplot(data         = DC_sf,
                      variable     = "pct_black",
                      label        = "GIS_ID",
                      neighbours   = NeighbourMatrix,
                      weights      = WeightsMatrix_standardised,
                      annotate     = TRUE,
                      palette      = 2,
                      significance = 0.1,
                      nsim         = 499,
                      seed         = 364,
                      title        = "Percent Black per DC census tract")
     #  Annotate turns the background color on and off
     #  p-value currently set to 0.1, change it to your threshold           

          
     
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     # You can also add our other layers to see how the pattern overlays
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     lisa_map(data  = DC_sf,
              variable     = "pct_black",
              label        = "GIS_ID",
              neighbours   = NeighbourMatrix,
              weights      = WeightsMatrix_standardised,
              significance = 0.1,
              seed         = 364,
              palette      = 2,
              nsim         = 499,
              mode         = "plot",
              title        = "Percent Black per DC census tract",
              data_source  = "Data: US Census 2000.") + 
     tm_shape(extra_wards) + 
       tm_borders(lwd=1.5)
     
     # or 
     
     # add historic zones
     tmap_mode("view")
     lisa_map(data  = DC_sf,
              variable     = "pct_black",
              label        = "GIS_ID",
              neighbours   = NeighbourMatrix,
              weights      = WeightsMatrix_standardised,
              significance = 0.1,
              seed         = 364,
              palette      = 2,
              nsim         = 499,
              mode         = "plot",
              title        = "Percent Black per DC census tract",
              data_source  = "Data: US Census 2000.") +      tm_shape(extra_FHA) +
       tm_borders(col = "Grade_class",
                  col.scale   = tm_scale_ordinal(values = c("darkgreen", "firebrick2")),
                  lwd         = 2,
                  col.legend  = tm_legend(title = "1937 FHA Zone"))
     
     
#============================================================================
# 10. GEARY'S C AND THE GETIS-ORD GENERAL G
#
# Moran's I compares each tract with the overall MEAN.
# Geary's C compares each tract DIRECTLY with its neighbours, by looking at
# the squared difference between them.
#
#     C near 0     = neighbours have similar values    (clustered)
#     C near 1     = no spatial pattern                (what random chance gives)
#     C above 1    = neighbours have different values  (checkerboard)
#
# Notice this runs the opposite way to Moran's I: a SMALL C means clustering.
#
# Section 10a) Global Geary's C: one number for the whole study area
# Section 10b) Global Getis-Ord General G: one number for the whole study area
# Section 10c) Local Geary's C: one number for every tract
# Section 10d) Maps of Local Geary's C
#============================================================================
     
     
  #----------------------------------------------------------------------
  # 10a) GLOBAL GEARY'S C
  #     As with Global Moran's I, there is more than one way to get the p-value
  #     The options are the same as the Moran's I test.   
  #----------------------------------------------------------------------
     
     #---- Geary's C, with the p-value from a formula (the randomization assumption)
     global_c_test(x  = DC_sf$pct_black,
                   nb = NeighbourMatrix,
                   wt = WeightsMatrix_standardised,
                   randomization = TRUE,
                   alternative   = "two.sided")
     
     
     #---- Geary's C, with the p-value from shuffling the data 999 times (Monte Carlo)
     set.seed(364)
     global_c_perm(x  = DC_sf$pct_black,
                   nb = NeighbourMatrix,
                   wt = WeightsMatrix_standardised,
                   nsim        = 999,
                   alternative = "two.sided")
     
     
     #----------------------------------------------------------------------
     # 10b) GLOBAL GETIS-ORD GENERAL G
     #
     #     Moran's I and Geary's C tell you IF values are clustered.
     #     The General G tells you WHICH values are clustered:
     #
     #        G higher than expected = the HIGH values are clustered together
     #        G lower than expected  = the LOW values are clustered together
     #
     #     Binary weights are recommended for Getis-Ord statistics,
     #     so this uses WeightsMatrix_binary
     #----------------------------------------------------------------------
     global_g_test(x  = DC_sf$pct_black,
                   nb = NeighbourMatrix,
                   wt = WeightsMatrix_binary,
                   alternative = "two.sided")
     
     
     
     
     
     #----------------------------------------------------------------------
     # 10c) LOCAL GEARY'S C
     #
     #     Every tract gets its own Geary's C value and its own p-value.
     #        A SMALL value = this tract is similar to its neighbours
     #        A LARGE value = this tract is different to its neighbours
     #
     #     The p-values come from shuffling the data nsim times.
     #----------------------------------------------------------------------
     
     #---- Calculate Local Geary's C and its p-values for every tract
     set.seed(364)
     LocalGeary <- local_c_perm(x  = DC_sf$pct_black,
                                nb = NeighbourMatrix,
                                wt = WeightsMatrix_standardised,
                                nsim        = 999,
                                alternative = "two.sided")
     
     
     #---- Look at the first few rows of the results
     head(LocalGeary)
     
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     # CODE EXPLANATION
     #   local_c_perm() gives back a table with one row per tract.
     #   The two columns we use are:
     #       ci            the Local Geary's C value
     #       p_folded_sim  the p-value from the random shuffles
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     
    

     #---- Then make a sf data object to hold the results without cluttering your main data
     #        (the tract label, pct_black and the geometry)
     Geary_pctblack_sf <- DC_sf[ , c("GIS_ID", "pct_black")]
     
     
     #---- Add the Local Geary's C values and the p-values as new columns
     Geary_pctblack_sf$Local_Geary_C <- LocalGeary$ci
     Geary_pctblack_sf$Local_Geary_p <- LocalGeary$p_folded_sim
     
     
     #---- Then adjust the p-values for the number of tests (Benjamini-Hochberg)
     Geary_pctblack_sf$Local_Geary_p_adj <- p.adjust(Geary_pctblack_sf$Local_Geary_p,
                                                     method = "BH")
     
     
     #---- Finally, Label each tract as significant or not, using the adjusted p-value
     Geary_pctblack_sf$Significant <- ifelse(Geary_pctblack_sf$Local_Geary_p_adj < 0.05,
                                             "Significant",
                                             "Not Significant (p>0.05)")
     
     
     #---- Look at the first few rows, and count how many tracts are in each group
     head(st_drop_geometry(Geary_pctblack_sf))
     table(Geary_pctblack_sf$Significant)
     
     
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     # WHY ADJUST THE P-VALUES?
     #   Every tract gets its own test. With this many tests, some tracts
     #   will look significant by chance alone (the multiple testing problem).
     #   The Benjamini-Hochberg method makes the p-values larger to allow for this.
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     
     
     
     
     #----------------------------------------------------------------------
     # 10d) MAPS OF LOCAL GEARY'S C
     #
     # We make three maps, then show them together at the end.
     # Nothing appears on your screen until the last command, tmap_arrange()
     #----------------------------------------------------------------------
     tmap_mode("plot")
     
     
     #---- Map Local Geary's C with a continuous colour scale
     map_Geary_continuous <- tm_shape(Geary_pctblack_sf) +
       tm_polygons(fill = "Local_Geary_C",
                   fill.scale  = tm_scale_continuous(),
                   fill.legend = SameLegend("Local Geary's C")) + SameLayout
     
     
     #---- Map Local Geary's C in five classes, using Jenks breaks
     map_Geary_jenks      <- tm_shape(Geary_pctblack_sf) +
       tm_polygons(fill = "Local_Geary_C",
                   fill.scale  = tm_scale_intervals(
                     style  = "jenks",
                     n      = 5,
                     values = "brewer.or_rd"),
                   fill.legend = SameLegend("Local Geary's C")) + SameLayout
     
     
     #---- Map which tracts are statistically significant
     map_Geary_significant <- tm_shape(Geary_pctblack_sf) +
       tm_polygons(fill = "Significant",
                   fill.scale  = tm_scale_categorical(),
                   fill.legend = SameLegend("Statistical Significance")) + SameLayout
     
     
     #---- And finally.. show the three maps together
     tmap_arrange(map_Geary_jenks, map_Geary_continuous,map_Geary_significant,nrow=2)
     

     
     
     
     
     
     
     
#============================================================================
#     
# 11. GETIS-ORD Gi AND Gi* (Hot spot and cold spot analysis)
# 
# Rather than examining all four quadrants of the moran scatterplot, here we simply
# assess if the local neighbourhood is higher or lower than the overall average
#     
# Gi  ("G-i")      leaves each tract's own value OUT and uses only its neighbours.
#                  It asks: "is this tract surrounded by a cluster?"
#
# Gi* ("G-i-star") counts each tract TOGETHER WITH its neighbours.
#                  It asks: "is this tract part of a cluster?"
#
# Both give every tract a z-score and a p-value:
#     positive z-score, small p-value = hot spot  (high values clustered together)
#     negative z-score, small p-value = cold spot (low values clustered together)
#
# Binary weights are recommended for Getis-Ord statistics,
# so this section uses WeightsMatrix_binary
#
#     
# 11A) Makes the finished map. This is what you normally do if it wasn't a class exercise
#     There is an option to turn on and off a correction for mulitple testing
#     
# 11B) shows how the Getis-Ord and Getis-ord* maps are made by plotting the map components
#     
#=========================================================================


     
  #----------------------------------------------------------------------
  # 11A. THE FINISHED GETIS-ORD MAPS
  #
  # Each command prints a table of how many tracts are in each group, then draws the map.
  # 
  # HOW TO READ THESE MAPS
  #   The p-values come from shuffling the data nsim times.
  #   A tract is a hot or cold spot at:
  #       90% confidence if p <= 0.10
  #       95% confidence if p <= 0.05
  #       99% confidence if p <= 0.01
  #
  #   Because of the shuffling, the map changes slightly each time.
  #   Give a seed (any whole number) to get the same map every time.
  #   The seed that was used is written under the map.
  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     
  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  # NOTES,    
  # Change mode = "plot" to mode = "view" for an interactive version
  #   
  #   adjust_p:     The maps in section 1 test every tract separately. 
  #                 With many tracts, some will look significant by chance alone. 
  #                 (multiple testing problem). So adjust_p = TRUE adjusts 
  #                 the p-values for the number of tests before the tracts are put into groups.
  #                 (using the Benjamini-Hochberg method)
  #
  #   Try turning it off and on. Expect FEWER hot and cold spots when it's on.  
  #   
  #   Also remember the normal mode = "plot" vs mode = "view" to turn on the interactive versions
  #----------------------------------------------------------------------
     
     
     #---- Gi: neighbours only
     getis_map(data        = DC_sf,
               variable    = "pct_black",
               label       = "GIS_ID",
               neighbours  = NeighbourMatrix,
               weights     = WeightsMatrix_binary,
               nsim        = 999,
               seed        = 123,
               adjust_p    = TRUE,
               title       = "Percent Black per DC census tract",
               data_source = "Data: US Census 2000.",
               mode        = "plot")
     
     
     
     #---- Gi*: each tract together with its neighbours
     getisstar_map(data        = DC_sf,
                   variable    = "pct_black",
                   label       = "GIS_ID",
                   neighbours  = NeighbourMatrix,
                   weights     = WeightsMatrix_binary,
                   nsim        = 999,
                   seed        = 123,
                   adjust_p    = TRUE,
                   title       = "Percent Black per DC census tract",
                   data_source = "Data: US Census 2000.",
                   mode        = "plot")
     
     
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     # Again, you can add extra layers
     # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     
     # add voting wards to getis map
     getis_map(data        = DC_sf,
               variable    = "pct_black",
               label       = "GIS_ID",
               neighbours  = NeighbourMatrix,
               weights     = WeightsMatrix_binary,
               nsim        = 999,
               seed        = 123,
               adjust_p    = TRUE,
               title       = "Percent Black per DC census tract",
               data_source = "Data: US Census 2000.",
               mode        = "view") + 
     tm_shape(extra_wards) + 
       tm_borders(lwd=1.5)
     
     # or add historic zones to getis* map
     getisstar_map(data        = DC_sf,
                   variable    = "pct_black",
                   label       = "GIS_ID",
                   neighbours  = NeighbourMatrix,
                   weights     = WeightsMatrix_binary,
                   nsim        = 999,
                   seed        = 123,
                   adjust_p    = TRUE,
                   title       = "Percent Black per DC census tract",
                   data_source = "Data: US Census 2000.",
                   mode        = "view") + 
       tm_shape(extra_FHA) +
          tm_borders(col = "Grade_class",
                     col.scale   = tm_scale_ordinal(values = c("darkgreen", "firebrick2")),
                     lwd         = 2,
                     col.legend  = tm_legend(title = "1937 FHA Zone"))
     
     
     
     
     
  #----------------------------------------------------------------------
  # 11B. UNDERSTANDING THE GETIS-ORD MAPS: 
  # Here we can see the underlying Z-scores and probabilities for the two methods   
  #   
  # We make four maps, then show them together at the end.
  # Nothing appears on your screen until the last command, tmap_arrange()
  #----------------------------------------------------------------------

    #---- Get the raw data behind the maps for getis
     DC_withGi_sf    <- getis_map(data        = DC_sf,
                                  variable    = "pct_black",
                                  label       = "GIS_ID",
                                  neighbours  = NeighbourMatrix,
                                  weights     = WeightsMatrix_binary,
                                  nsim        = 999,
                                  seed        = 123,
                                  silent      = TRUE,
                                  adjust_p    = TRUE,
                                  return_data = TRUE)
    
     
     #---- Get the raw data behind the maps for getis-ord*
     DC_withGstar_sf <- getisstar_map(data        = DC_sf,
                                      variable    = "pct_black",
                                      label       = "GIS_ID",
                                      neighbours  = NeighbourMatrix,
                                      weights     = WeightsMatrix_binary,
                                      nsim        = 999,
                                      seed        = 123,
                                      silent      = TRUE,
                                      adjust_p    = TRUE,
                                      return_data = TRUE)

    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    # CODE EXPLANATION
    #   return_data = TRUE gives back a small sf data object in place of the map.
    #   It holds the tract label, pct_black, the geometry and three new columns:
    #       Gi:   getis.z,      getis.pvalue      and getis.cluster
    #       Gi*:  getisstar.z,  getisstar.pvalue  and getisstar.cluster
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

     
     #---- Find the overall range of Z (for the color scale)
     largest_z <- max(abs(c(DC_withGi_sf$getis.z, DC_withGstar_sf$getisstar.z)))
     


     #---- Map the Z score of the Getis-Ord output
     map_Gi_Z     <- tm_shape(DC_withGi_sf) +
                         tm_polygons(fill = "getis.z",
                              fill.scale  = tm_scale_intervals(
                                               values   = "-brewer.rd_bu",
                                               midpoint = 0, 
                                               breaks   = seq(-largest_z, 
                                                              largest_z,
                                                              length.out = 8)),
                              fill.legend = SameLegend("Gi z-score")) + SameLayout

     

     #---- Map the Z score of the Getis-Ord* output
     map_GiStar_Z <- tm_shape(DC_withGstar_sf) +
                         tm_polygons(fill = "getisstar.z",
                              fill.scale  = tm_scale_intervals(
                                                values   = "-brewer.rd_bu", 
                                                midpoint = 0,
                                                breaks   = seq(-largest_z, 
                                                               largest_z, 
                                                               length.out = 8)),
                              fill.legend = SameLegend("Gi* z-score")) + SameLayout



    #---- Sort out combined color scales for the two sets of p-values
     p_breaks  <- c(0, 0.01, 0.05, 0.10, 1)
     p_colours <- c("#006d2c", "#238b45", "#99d8c9", "white")
     p_labels  <- c("p <= 0.01", "0.01 - 0.05", "0.05 - 0.10", "p > 0.10")


     
     
     #---- Map the p-value  of the Getis-Ord output
     map_Gi_p     <- tm_shape(DC_withGi_sf) +
                        tm_polygons(fill = "getis.pvalue",
                             fill.scale  = tm_scale_intervals(
                                                breaks = p_breaks,
                                                values = p_colours,
                                                labels = p_labels),
                             fill.legend = SameLegend("Gi p-value")) + SameLayout

     
     
     
     #---- Map the p-value  of the Getis-Ord* output
     map_GiStar_p <- tm_shape(DC_withGstar_sf) +
                        tm_polygons(fill = "getisstar.pvalue",
                              fill.scale  = tm_scale_intervals(
                                                breaks = p_breaks,
                                                values = p_colours,
                                                labels = p_labels),
                        fill.legend = SameLegend("Gi* p-value")) + SameLayout

    
     
    #---- And finally.. show the four maps together
     tmap_arrange(map_Gi_Z, map_Gi_p,map_GiStar_Z, map_GiStar_p, ncol = 2)
     
     
     
     

###########################################################################
# SUMMARY MAP OF MORAN VS GETIS VS GETIS*
###########################################################################
#=========================================================================
# The autocorrelation summary function in sfdepmap will allow you to see 
# all of these measures in the same place.
#     
# This means the plot is large! 
#     
#  -  If you choose "plot", then the code below is set up to save the resulting plot to file
#      Simply go to your files tab and click on your chosen filename.  
#     
#  -  If you choose "view", then click zoom to open in a new screen, then maximise your screen
#     
#=========================================================================
     
     
  #----------------------------------------------------------------------
  # THE FOUR-MAP SUMMARY FIGURE - PLOT FOR YOUR REPORTS
  #
  #     One command makes one figure with four maps, using the standard settings:
  #        A. your data          B. LISA clusters
  #        C. Gi* hot spots      D. Gi hot spots
  #     and one caption underneath, which includes the global statistics.
  #
  # This will save as a file in your project folder. 
  #----------------------------------------------------------------------

     graphics.off()
     png("AutocorrelationSummary_DC_pct_black.png",width=9,height=9,units = "in",res=200)
     
     autocorrelation_summary(data         =  DC_sf,
                             variable     = "pct_black",
                             label        = "GIS_ID",
                             neighbours   = NeighbourMatrix,
                             weights      = WeightsMatrix_standardised,
                             basemap      = TRUE,
                             seed         = 100,  
                             significance = 0.01,
                             nsim         = 499,
                             adjust_p     = TRUE,
                             title        = "Percentage of adults identifying 
                                             as Black (1st order Queens)",
                             data_source  = "Data: US Census, 2000",
                             explanation  = TRUE,
                             global_stats = TRUE,
                             mode         = "plot")
     
     graphics.off()
     message(paste("Image saved in Project folder:\n",getwd()))
     

  #----------------------------------------------------------------------
  # THE FOUR-MAP SUMMARY FIGURE - INTERACTIVE
  #
  #     One command makes one figure with four maps, using the standard settings:
  #        A. your data          B. LISA clusters
  #        C. Gi* hot spots      D. Gi hot spots
  #
  # This is interactive to let you explore it. remember you can click the 
  # layers button to change the basemap   
  #----------------------------------------------------------------------
     
     autocorrelation_summary(data         =  DC_sf,
                             variable     = "pct_black",
                             label        = "GIS_ID",
                             neighbours   = NeighbourMatrix,
                             weights      = WeightsMatrix_standardised,
                             basemap      = TRUE,
                             seed         = 100,  
                             significance = 0.01,
                             nsim         = 499,
                             adjust_p     = TRUE,
                             title        = "Percentage adults identifying 
                                            as Black (1st order Queens)",
                             data_source  = "Data: US Census.",
                             explanation  = TRUE,
                             global_stats = TRUE,
                             mode         = "view")
     
     
     